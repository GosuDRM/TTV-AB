// TTV AB - UI

const _REMINDER_KEY = "ttvab_last_reminder";
const _REMINDER_INTERVAL = 1209600000;
const _FIRST_RUN_KEY = "ttvab_first_run_shown";
const _UI_FLAGS_KEY = "__TTVAB_UI_FLAGS__";
type UiFlags = {
	achievementListenerInitialized: boolean;
	welcomeScheduled: boolean;
	donationScheduled: boolean;
};

function _getUiStorageItem(key) {
	try {
		return localStorage.getItem(key);
	} catch (e) {
		_log(`UI storage read error for ${key}: ${e.message}`, "error");
		return null;
	}
}

function _setUiStorageItem(key, value) {
	try {
		localStorage.setItem(key, value);
		return true;
	} catch (e) {
		_log(`UI storage write error for ${key}: ${e.message}`, "error");
		return false;
	}
}

function _escapeUiText(value) {
	const div = document.createElement("div");
	div.textContent = String(value ?? "");
	return div.innerHTML;
}

function _getUiFlags(): UiFlags {
	const existing = window[_UI_FLAGS_KEY];
	if (existing && typeof existing === "object") {
		return existing as UiFlags;
	}
	const flags: UiFlags = {
		achievementListenerInitialized: false,
		welcomeScheduled: false,
		donationScheduled: false,
	};
	window[_UI_FLAGS_KEY] = flags;
	return flags;
}

function _showDonation() {
	try {
		const uiFlags = _getUiFlags();
		if (uiFlags.donationScheduled) return;
		const lastReminder = _getUiStorageItem(_REMINDER_KEY);
		const now = Date.now();

		if (!lastReminder) {
			_setUiStorageItem(_REMINDER_KEY, now.toString());
			return;
		}

		const lastReminderMs = Number.parseInt(lastReminder, 10);
		if (!Number.isFinite(lastReminderMs) || lastReminderMs > now) {
			_setUiStorageItem(_REMINDER_KEY, now.toString());
			return;
		}

		if (now - lastReminderMs < _REMINDER_INTERVAL) return;

		uiFlags.donationScheduled = true;
		setTimeout(() => {
			uiFlags.donationScheduled = false;
			if (document.getElementById("ttvab-reminder") || !document.body) return;
			const toast = document.createElement("div");
			toast.id = "ttvab-reminder";
			toast.innerHTML = `
                <style>
                    #ttvab-reminder{position:fixed;bottom:20px;right:20px;background:linear-gradient(135deg,#9146FF 0%,#772CE8 100%);color:#fff;padding:16px 20px;border-radius:12px;font-family:'Segoe UI',sans-serif;font-size:14px;max-width:320px;box-shadow:0 4px 20px rgba(0,0,0,.3);z-index:999999;animation:ttvab-slide .3s ease}
                    @keyframes ttvab-slide{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
                    #ttvab-reminder-close{position:absolute;top:8px;right:10px;background:none;border:none;color:rgba(255,255,255,.7);font-size:18px;cursor:pointer;padding:0;line-height:1}
                    #ttvab-reminder-close:hover{color:#fff}
                    #ttvab-reminder-btn{display:inline-block;margin-top:10px;padding:8px 16px;background:#fff;color:#772CE8;border:none;border-radius:6px;font-weight:600;cursor:pointer;font-size:13px}
                    #ttvab-reminder-btn:hover{background:#f0f0f0}
                </style>
                <button id="ttvab-reminder-close">×</button>
                <div style="margin-bottom:4px;font-weight:600">💜 Enjoying TTV AB?</div>
                <div style="opacity:.9">If this extension saves you from ads, consider buying me a coffee!</div>
                <button id="ttvab-reminder-btn">Support the Developer</button>
            `;

			document.body.appendChild(toast);
			_setUiStorageItem(_REMINDER_KEY, now.toString());

			const reminderClose = toast.querySelector("#ttvab-reminder-close");
			if (reminderClose) {
				reminderClose.onclick = () => toast.remove();
			}
			const reminderButton = toast.querySelector("#ttvab-reminder-btn");
			if (reminderButton) {
				reminderButton.onclick = () => {
					window.open(
						"https://ko-fi.com/gosudrm",
						"_blank",
						"noopener,noreferrer",
					);
					if (toast.isConnected) {
						toast.remove();
					}
				};
			}

			setTimeout(() => {
				if (toast.isConnected) {
					toast.style.animation = "ttvab-slide .3s ease reverse";
					setTimeout(() => toast.remove(), 300);
				}
			}, 15000);
		}, 5000);
	} catch (e) {
		_log(`Donation reminder error: ${e.message}`, "error");
	}
}

function _showWelcome() {
	try {
		const uiFlags = _getUiFlags();
		if (uiFlags.welcomeScheduled || _getUiStorageItem(_FIRST_RUN_KEY)) return;

		uiFlags.welcomeScheduled = true;
		setTimeout(() => {
			uiFlags.welcomeScheduled = false;
			if (document.getElementById("ttvab-welcome") || !document.body) return;
			const toast = document.createElement("div");
			toast.id = "ttvab-welcome";
			toast.innerHTML = `
                <style>
                    #ttvab-welcome{position:fixed;top:20px;right:20px;background:linear-gradient(135deg,#9146FF 0%,#772CE8 100%);color:#fff;padding:20px 24px;border-radius:16px;font-family:'Segoe UI',sans-serif;font-size:14px;max-width:340px;box-shadow:0 8px 32px rgba(0,0,0,.4);z-index:999999;animation:ttvab-welcome .4s ease}
                    @keyframes ttvab-welcome{from{opacity:0;transform:translateY(-20px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}
                    #ttvab-welcome-close{position:absolute;top:10px;right:12px;background:none;border:none;color:rgba(255,255,255,.7);font-size:20px;cursor:pointer;padding:0;line-height:1}
                    #ttvab-welcome-close:hover{color:#fff}
                    #ttvab-welcome h3{margin:0 0 8px;font-size:18px}
                    #ttvab-welcome p{margin:0 0 12px;opacity:.9;line-height:1.4}
                    #ttvab-welcome .pin-tip{background:rgba(255,255,255,.15);padding:10px 12px;border-radius:8px;font-size:13px}
                    #ttvab-welcome .pin-tip strong{color:#fff}
                </style>
                <button id="ttvab-welcome-close">×</button>
                <h3>🎉 TTV AB Installed!</h3>
                <p>Ads will now be blocked automatically on Twitch streams.</p>
                <div class="pin-tip">
                    <strong>💡 Tip:</strong> Pin this extension for easy access!<br>
                    Click 🧩 → Find TTV AB → Click 📌
                </div>
            `;

			document.body.appendChild(toast);
			_setUiStorageItem(_FIRST_RUN_KEY, "true");

			const closeHandler = () => {
				toast.style.animation = "ttvab-welcome .3s ease reverse";
				setTimeout(() => toast.remove(), 300);
			};

			const welcomeClose = toast.querySelector("#ttvab-welcome-close");
			if (welcomeClose) {
				welcomeClose.onclick = closeHandler;
			}

			setTimeout(() => {
				if (toast.isConnected) closeHandler();
			}, 10000);
		}, 2000);
	} catch (e) {
		_log(`Welcome message error: ${e.message}`, "error");
	}
}

const _ACHIEVEMENT_INFO = {
	first_block: { name: "Ad Slayer", icon: "⚔️", desc: "Blocked your first ad!" },
	block_10: { name: "Blocker", icon: "🛡️", desc: "Blocked 10 ads!" },
	block_100: { name: "Guardian", icon: "🔰", desc: "Blocked 100 ads!" },
	block_500: { name: "Sentinel", icon: "🏰", desc: "Blocked 500 ads!" },
	block_1000: { name: "Legend", icon: "🏆", desc: "Blocked 1000 ads!" },
	block_5000: { name: "Mythic", icon: "👑", desc: "Blocked 5000 ads!" },
	time_1h: { name: "Hour Saver", icon: "⏱️", desc: "Saved 1 hour from ads!" },
	time_10h: {
		name: "Time Master",
		icon: "⏰",
		desc: "Saved 10 hours from ads!",
	},
	channels_5: {
		name: "Explorer",
		icon: "📺",
		desc: "Blocked ads on 5 channels!",
	},
	channels_20: {
		name: "Adventurer",
		icon: "🌍",
		desc: "Blocked ads on 20 channels!",
	},
	block_10000: {
		name: "Diamond",
		icon: "💎",
		desc: "Blocked 10,000 ads!",
	},
	channels_50: {
		name: "Globetrotter",
		icon: "🗺️",
		desc: "Blocked ads on 50 channels!",
	},
};

function _ensureAchievementToastStyles() {
	if (document.getElementById("ttvab-achievement-style")) return;
	const style = document.createElement("style");
	style.id = "ttvab-achievement-style";
	style.textContent =
		"#ttvab-achievement{position:fixed;top:20px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,#1a1a2e 0%,#16213e 100%);color:#fff;padding:16px 24px;border-radius:16px;font-family:'Segoe UI',sans-serif;box-shadow:0 8px 32px rgba(0,0,0,.5),0 0 20px rgba(145,70,255,.3);z-index:9999999;animation:ttvab-ach-pop .5s cubic-bezier(0.34,1.56,0.64,1);border:2px solid rgba(145,70,255,.5);display:flex;align-items:center;gap:16px}" +
		"@keyframes ttvab-ach-pop{from{opacity:0;transform:translateX(-50%) scale(.5) translateY(-20px)}to{opacity:1;transform:translateX(-50%) scale(1) translateY(0)}}" +
		"@keyframes ttvab-ach-shine{0%{background-position:-200% center}100%{background-position:200% center}}" +
		"#ttvab-achievement .ach-icon{font-size:40px;animation:ttvab-ach-bounce 1s ease infinite}" +
		"@keyframes ttvab-ach-bounce{0%,100%{transform:scale(1)}50%{transform:scale(1.1)}}" +
		"#ttvab-achievement .ach-content{display:flex;flex-direction:column;gap:2px}" +
		"#ttvab-achievement .ach-label{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#9146FF;font-weight:600}" +
		"#ttvab-achievement .ach-name{font-size:18px;font-weight:700;background:linear-gradient(90deg,#fff 0%,#9146FF 50%,#fff 100%);background-size:200% auto;-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;animation:ttvab-ach-shine 2s linear infinite}" +
		"#ttvab-achievement .ach-desc{font-size:12px;color:#aaa;margin-top:2px}";
	document.head?.appendChild(style);
}

function _showAchievementUnlocked(achievementId) {
	try {
		const ach = _ACHIEVEMENT_INFO[achievementId];
		if (!ach) return;

		if (!document.body) return;
		_ensureAchievementToastStyles();
		const existing = document.getElementById("ttvab-achievement");
		if (existing) existing.remove();

		const toast = document.createElement("div");
		toast.id = "ttvab-achievement";
		const icon = document.createElement("div");
		icon.className = "ach-icon";
		icon.textContent = String(ach.icon ?? "");

		const content = document.createElement("div");
		content.className = "ach-content";

		const label = document.createElement("div");
		label.className = "ach-label";
		label.textContent = "Achievement Unlocked!";

		const name = document.createElement("div");
		name.className = "ach-name";
		name.textContent = String(ach.name ?? "");

		const desc = document.createElement("div");
		desc.className = "ach-desc";
		desc.textContent = String(ach.desc ?? "");

		content.append(label, name, desc);
		toast.append(icon, content);

		document.body.appendChild(toast);
		_log(`Achievement unlocked: ${ach.name}`, "success");

		setTimeout(() => {
			if (toast.isConnected) {
				toast.style.animation = "ttvab-ach-pop .5s ease reverse";
				setTimeout(() => toast.remove(), 500);
			}
		}, 5000);
	} catch (e) {
		_log(`Achievement error: ${e.message}`, "error");
	}
}

function _initAchievementListener() {
	const uiFlags = _getUiFlags();
	if (uiFlags.achievementListenerInitialized) return;
	uiFlags.achievementListenerInitialized = true;
	_onInternalMessage("ttvab-achievement-unlocked", (detail) => {
		const safeDetail =
			detail && typeof detail === "object" && !Array.isArray(detail)
				? detail
				: null;
		if (typeof safeDetail?.id !== "string") return;
		_showAchievementUnlocked(safeDetail.id);
	});
}
