// TTV AB - Worker Utils

type WorkerConstructor = new (...args: unknown[]) => Worker;

function _getWasmJs(url) {
	const req = new XMLHttpRequest();
	req.open("GET", url, false);
	req.send();
	return req.responseText;
}

function _cleanWorker(W: WorkerConstructor): WorkerConstructor {
	const CleanWorker = class extends W {};
	const proto = CleanWorker.prototype;
	for (const key of _S.conflicts) {
		if (key in proto) {
			Object.defineProperty(proto, key, {
				configurable: true,
				writable: true,
				value: undefined,
			});
		}
	}
	return CleanWorker as WorkerConstructor;
}

function _getReinsert(W) {
	const src = W.toString();
	const result = [];
	for (const pattern of _S.reinsertPatterns) {
		if (src.includes(pattern)) result.push(pattern);
	}
	return result;
}

function _reinsert(W, names) {
	for (const name of names) {
		if (typeof window[name] === "function") {
			W.prototype[name] = window[name];
		}
	}
	return W;
}

function _isValid(v) {
	if (typeof v !== "function") return false;
	const src = v.toString();
	return (
		!_S.conflicts.some((c) => src.includes(c)) &&
		!_S.reinsertPatterns.some((p) => src.includes(p))
	);
}
